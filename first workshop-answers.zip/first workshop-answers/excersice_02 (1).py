def chessboard(houses=1, string=""):
    columns = range(0, houses)
    rows = range(0, houses)
    pattern = ""
    for row in rows:
        for column in columns:
            pattern += string+" "
        pattern += "\n"
    print(pattern)


chessboard(5, "==")
