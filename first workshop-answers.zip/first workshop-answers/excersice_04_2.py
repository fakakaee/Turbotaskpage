from excersice_04 import edit_distance


def lazy_reader(path):
    with open(path) as file:
        return file.readlines()


words = lazy_reader("words_input.txt")
distance_map, len_words = dict(), len(words)
for pointer in range(0, len_words):
    if pointer + 1 > len_words - 1:
        break
    w1 = words[pointer].strip()
    w2 = words[pointer + 1].strip()
    distance = edit_distance(w1, w2)
    if distance not in distance_map:
        distance_map[distance] = []

    distance_map[distance].append([w1, w2])

for k, v in distance_map.items():
    print("For {k} distance we have {v}".format(k=k, v=v))

print("""
We have {least_distance} words with distance 1 or 2 or 3.
Also we have this words pair with 1 unit of edit distance,
{one_unit_distance_words}
""".format(
    least_distance=len(distance_map.get(1)) + len(distance_map.get(2)) + len(distance_map.get(3)),
    one_unit_distance_words=distance_map.get(1)
))
