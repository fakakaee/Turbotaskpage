def fibonacci(n):
    if n < 0:
        return None
    elif n == 0 or n == 1:
        return n
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)


sequence = []


def calculate(n):
    nth = 0
    result = fibonacci(nth)
    sequence.append(result)
    can_continue = True
    while can_continue:
        nth = nth + 1
        result = fibonacci(nth)
        if result <= n:
            sequence.append(result)
        else:
            can_continue = False
    return sequence


print(calculate(100))
