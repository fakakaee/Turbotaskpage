from Bank import Bank

bank = Bank()
""" Saving Account """
saving_account = bank.saving().create_account()
balance = saving_account.deposite(100)
print("Your #1 balance is {}".format(balance))

balance = saving_account.withdraw(50)
print("Your #2 balance is {}".format(balance))

balance = saving_account.deposite(75)
print("Your #3 balance is {}".format(balance))

""" Investment Account """
investment_account = bank.investment().create_account()
investment_account.interest(18)
balance = investment_account.deposite(100)
print("Your #1 balance is {}".format(balance))

balance = investment_account.withdraw(50)
print("Your #2 balance is {}".format(balance))

balance = investment_account.deposite(77)
print("Your #3 balance is {}".format(balance))
