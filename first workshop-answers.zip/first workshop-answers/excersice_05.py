def same_letters(words: list, my_dictionary: dict) -> dict:
    for first_word in words:
        first_word_letters = frozenset(first_word)
        for nth_word in words:
            nth_word_letters = frozenset(nth_word)
            if first_word_letters == nth_word_letters:
                if first_word_letters not in my_dictionary:
                    my_dictionary[first_word_letters] = []
                my_dictionary[first_word_letters].append(nth_word)

    return my_dictionary


dictionary = dict()
file = open("sentences_input.txt", encoding="windows-1252")
while file:
    readline = file.readline()
    if readline == "":
        break
    same_letters(words=readline.strip().split(" "), my_dictionary=dictionary)
file.close()

for k, v in dictionary.items():
    print("""
        For letters {letters} we have these words: {words}
    """.format(letters=k, words=v).strip())
