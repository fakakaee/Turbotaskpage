import random

names = [
    "Mohammad",
    "Shahrbanoo",
    "Shayan",
    "MohammadReza",
    "Sara",
    "Ashkan",
    "Mohammad Bagher",
    "Asal",
    "Tara",
]


def lottery(list_of_names=None, weights=None):
    if weights is None:
        weights = []

    if list_of_names is None:
        list_of_names = []

    if len(list_of_names) == 0:
        raise Exception("There is no choice!")

    if len(weights) == 0:
        return random.choice(list_of_names)

    return random.choices(list_of_names, weights, k=len(list_of_names))[0]


def run():
    try:
        with_odds = input("With odds or not? y/n => default:y\n")
        if with_odds == "y":
            weights = [random.uniform(0, 10) for x in range(len(names))]
            message = "Select {name} from {length} names with odds of: {odds}".format(
                name=lottery(list_of_names=names, weights=weights),
                length=len(names),
                odds=weights
            )
            print(message)

        elif with_odds == "n":
            message = "Select {name} from {length} names".format(
                name=lottery(list_of_names=names),
                length=len(names)
            )
            print(message)
        else:
            return run()
    except Exception as e:
        print(str(e))


def once_again():
    global again
    if answer == 'y':
        again = True
    else:
        again = False


""" Program starts here """
run()
again = False
answer = input("Once again? y/n => default=y\n")
once_again()
while again:
    run()
    once_again()

print("Have a good day")
