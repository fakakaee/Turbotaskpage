import Account


class Bank:
    type: Account.Saving | Account.Investment

    def investment(self):
        self.type = Account.Investment()
        return self

    def saving(self):
        self.type = Account.Saving()
        return self

    def create_account(self) -> Account.Saving | Account.Investment:
        if type is None:
            self.saving()

        return self.type
