class PositiveTransaction:
    amount: float = 0.0

    def get_amount(self) -> float:
        return self.amount

    def set_amount(self, amount: float):
        self.amount = amount
        return self


class NegativeTransaction(PositiveTransaction):
    def set_amount(self, amount: float):
        self.amount = amount * -1
        return self
