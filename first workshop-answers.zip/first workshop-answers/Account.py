import Transactions


class Saving:
    transactions: list = []

    def deposite(self, amount) -> float:
        transaction = Transactions.PositiveTransaction().set_amount(amount)
        self.transactions.append(transaction)
        return self.calculate_balance()

    def withdraw(self, amount) -> float:
        transaction = Transactions.NegativeTransaction().set_amount(amount)
        self.transactions.append(transaction)
        return self.calculate_balance()

    def calculate_balance(self) -> float:
        balance = 0.0
        for trx in self.transactions:
            balance += trx.get_amount()
        return balance


class Investment(Saving):
    rate: float = 0.0
    transactions: list = []

    def interest(self, rate: float) -> float:
        self.rate = rate
        return self.rate

    def calculate_interest(self, trx: Transactions.PositiveTransaction):
        interest = trx.get_amount() * self.rate / 100
        return interest

    def deposite(self, amount: float):
        """ Standard """
        transaction = Transactions.PositiveTransaction().set_amount(amount)
        self.transactions.append(transaction)
        balance = self.calculate_balance()
        if self.rate <= 0:
            return balance

        """ Interest """
        return self.calculate_balance_with_interest(balance)

    def calculate_balance_with_interest(self, balance) -> float:
        transaction = Transactions.PositiveTransaction().set_amount(balance * self.rate / 100)
        self.transactions.append(transaction)
        return self.calculate_balance()
